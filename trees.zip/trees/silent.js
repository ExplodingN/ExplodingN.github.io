console.log("I know where you stand, silent in the trees")
console.log("And that's where I am, silent in the trees")
console.log("Why won't you speak where I happen to be?")
console.log("Silent in the trees, standing cowardly")

